import React from "react";

interface DetectionResultsProps {
  results: { label: string; confidence: number }[] | null;
  isAnalyzing: boolean;
  imageUrl: string | null; // This should point to the *annotated* image
}

const DetectionResults: React.FC<DetectionResultsProps> = ({
  results,
  isAnalyzing,
  imageUrl,
}) => {
  if (!results && !isAnalyzing && !imageUrl) return null;

  return (
    <div className="space-y-4 mt-4 text-center">
      {isAnalyzing && (
        <p className="text-yellow-600 font-semibold">Analyzing image...</p>
      )}

      {imageUrl && (
        <div className="max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-green-600 mb-2">
            Fault Detection Results and Analysis
          </h3>
          <img
            src={imageUrl}
            alt="Detection Result"
            className="rounded shadow-lg mx-auto"
          />
        </div>
      )}

      {results && results.length > 0 && (
        <div className="mt-3 space-y-1">
          {results.map((result, index) => (
            <p key={index} className="text-sm text-gray-700">
              <span className="font-semibold">{result.label}</span>:{" "}
              {(result.confidence * 100).toFixed(1)}%
            </p>
          ))}
        </div>
      )}

      {!isAnalyzing && results && results.length === 0 && (
        <p className="text-gray-500">No faults detected in the image.</p>
      )}
    </div>
  );
};

export default DetectionResults;
